This is from https://github.com/AlliBalliBaba/Sokoban-Level-Generator/
Modified to generate an array data of a level.

select level size to 8
select desired box count
press generate
press optimize
press code copy
array data will be copied to clipboard

some generated levels are unsolvable.
